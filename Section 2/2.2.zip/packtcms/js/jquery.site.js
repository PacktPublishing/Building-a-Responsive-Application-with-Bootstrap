$(document).ready(function() {

	// JQUERY MASONRY
    $('.masonry-grid').masonry({
    	itemSelector: '.grid-item',
      	columnWidth: '.grid-item',
  		gutter: 0
	});


});