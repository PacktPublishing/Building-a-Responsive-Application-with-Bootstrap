$(document).ready(function() {

    // MOBILE MENU
    $('.page-container').on('click', '.mobile-menu', function(e) {
        e.preventDefault();
        $('.page-container').toggleClass('toggled');
    });


});