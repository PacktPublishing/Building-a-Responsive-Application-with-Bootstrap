$(document).ready(function() {

    // MOBILE MENU
    $('.page-container').on('click', '.mobile-menu', function(e) {
        e.preventDefault();
        $('.page-container').toggleClass('toggled');
    });


    // SHOW USER MODAL
    $('.page-container').on('click', '.show-user-modal', function(e) {
        e.preventDefault();

        var user_id = $(this).data('id');

        $.ajax({
            type: 'post',
            url: 'modals/user-modal.php',
            data: {
                'user_id': user_id
            },
            success: function(response) {
                $('#ajax-modal').html(response).modal('show');
            }
        });
    });

    // AJAX MODAL
    $('#ajax-modal').on('hidden.bs.modal', function (e) {
        $(this).empty();
    }); 

    // POPOVERS
    $('[data-toggle="popover"]').popover();

    $("[data-toggle=ajax-popover]").popover({
        html : true,
        placement: 'top',
        content: function() {
          var content = $(this).attr("data-popover-content");
          return $(content).html();
        }
    });

    // TOOLTIPS
    $('[data-toggle="tooltip"]').tooltip();

   

});